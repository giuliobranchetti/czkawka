Krokiet Duplicate Folders - Windows x64 development build

Extract the ZIP and run krokiet.exe. Select Duplicate Folders in the left sidebar.
This MVP performs analysis only; no deletion or move actions are available.

Built from giuliobranchetti/czkawka with Rust 1.94.1 and the software renderer.
The GUI was tested on Linux under Xvfb. Windows and actual SMB/NAS runtime execution
remain untested. This is an unoptimized fastci development build, not a release.
See Duplicate_Folders.md for behavior, limits, caching, and build instructions.
The included patch contains the implementation relative to the checked-out commit.
